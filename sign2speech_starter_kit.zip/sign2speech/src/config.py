from pydantic import BaseModel
from typing import Optional

class AppConfig(BaseModel):
    # Video
    camera_index: int = 0
    display: bool = True  # show OpenCV window
    
    # Detection
    detector_backend: str = "onnx"  # "onnx" | "ultralytics"
    onnx_model_path: str = "models/yolo_lg.onnx"  # replace with your YOLO-LG ONNX
    conf_threshold: float = 0.35
    iou_threshold: float = 0.45
    max_det: int = 5
    
    # Mapping
    mapping_path: str = "mapping.json"
    
    # NLP / Translation
    source_lang: str = "en"
    target_lang: str = "hi"  # 'hi' for Hindi, 'es' for Spanish, etc.
    translation_model: Optional[str] = None  # auto-pick if None
    
    # Text-to-Speech
    tts_backend: str = "pyttsx3"  # "pyttsx3" | "gtts"
    voice_rate: int = 170
    voice_volume: float = 1.0
    
    # Debounce / UX
    hold_frames: int = 8       # number of consecutive frames to accept a gesture
    cooldown_frames: int = 12  # frames to wait before accepting same gesture again
    sentence_max_tokens: int = 20
